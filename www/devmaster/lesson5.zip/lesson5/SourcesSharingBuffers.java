import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.Vector;

import net.java.games.joal.AL;
import net.java.games.joal.ALC;
import net.java.games.joal.ALFactory;
import net.java.games.joal.util.ALut;

/**
* Copyright (c) 2003 Sun Microsystems, Inc. All  Rights Reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* -Redistribution of source code must retain the above copyright notice, 
* this list of conditions and the following disclaimer.
*
* -Redistribution in binary form must reproduce the above copyright notice, 
* this list of conditions and the following disclaimer in the documentation
* and/or other materials provided with the distribution.
*
* Neither the name of Sun Microsystems, Inc. or the names of contributors may 
* be used to endorse or promote products derived from this software without 
* specific prior written permission.
* 
* This software is provided "AS IS," without a warranty of any kind.
* ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
* ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
* NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN MIDROSYSTEMS, INC. ("SUN") AND ITS
* LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A
* RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
* IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT
* OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR
* PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY,
* ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN IF SUN HAS
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
*
* You acknowledge that this software is not designed or intended for use in the
* design, construction, operation or maintenance of any nuclear facility.
*
* Created on Jul 8, 2003
*/

/**
 * @author Athomas Goldberg
 *
 */
public class SourcesSharingBuffers {

    static ALC alc;
    static AL al;

//     These index the buffers.
    public static final int THUNDER     = 0;
    public static final int WATERDROP   = 1;
    public static final int STREAM      = 2;
    public static final int RAIN        = 3;

    public static final int CHIMES      = 4;
    public static final int OCEAN       = 5;
    public static final int NUM_BUFFERS = 6;

//     Buffers hold sound data.
    static int[] buffers = new int[NUM_BUFFERS];

//     A vector list of sources for multiple emissions.
    static Vector sources = new Vector();

//  Position of the source sounds.
    static float[] sourcePos = { 0.0f, 0.0f, 0.0f };

//  Velocity of the source sounds.
    static float[] sourceVel = { 0.0f, 0.0f, 0.0f };



//  Position of the listener.
    static float[] listenerPos = { 0.0f, 0.0f, 0.0f };

//  Velocity of the listener.
    static float[] listenerVel = { 0.0f, 0.0f, 0.0f };

//  Orientation of the listener. (first 3 elements are "at", second 3 are "up")
    static float[] listenerOri = { 0.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f };

    static int initOpenAL() {
        alc = ALFactory.getALC();
        al = ALFactory.getAL();

        ALC.Device device;
        ALC.Context context;
        String deviceSpecifier;
        String deviceName = "DirectSound3D";

        // Get handle to device.
        device = alc.alcOpenDevice(deviceName);

        // Get the device specifier.
        deviceSpecifier = alc.alcGetString(device, ALC.ALC_DEVICE_SPECIFIER);

        System.out.println("Using device " + deviceSpecifier);

        // Create audio context.
        context = alc.alcCreateContext(device, null);

        // Set active context.
        alc.alcMakeContextCurrent(context);

        // Check for an error.
        if (alc.alcGetError(device) != ALC.ALC_NO_ERROR)
            return AL.AL_FALSE;

        return AL.AL_TRUE;
    }

    static void exitOpenAL() {
        ALC.Context curContext;
        ALC.Device curDevice;

        // Get the current context.
        curContext = alc.alcGetCurrentContext();

        // Get the device used by that context.
        curDevice = alc.alcGetContextsDevice(curContext);

        // Reset the current context to NULL.
        alc.alcMakeContextCurrent(null);

        // Release the context and the device.
        alc.alcDestroyContext(curContext);
        alc.alcCloseDevice(curDevice);
    }
    static int loadALData() {
        // Variables to load into.
        int[] format = new int[1];
        int[] size = new int[1];
        ByteBuffer[] data = new ByteBuffer[1];
        int[] freq = new int[1];
        int[] loop = new int[1];

        // Load wav data into buffers.
        al.alGenBuffers(NUM_BUFFERS, buffers);

        if(al.alGetError() != AL.AL_NO_ERROR)
            return AL.AL_FALSE;

        ALut.alutLoadWAVFile("wavdata/thunder.wav", format, data, size, freq, loop);
        al.alBufferData(buffers[THUNDER], format[0], data[0], size[0], freq[0]);
        ALut.alutUnloadWAV(format[0], data[0], size[0], freq[0]);

        ALut.alutLoadWAVFile("wavdata/waterdrop.wav", format, data, size, freq, loop);
        al.alBufferData(buffers[WATERDROP], format[0], data[0], size[0], freq[0]);
        ALut.alutUnloadWAV(format[0], data[0], size[0], freq[0]);

        ALut.alutLoadWAVFile("wavdata/stream.wav", format, data, size, freq, loop);
        al.alBufferData(buffers[STREAM], format[0], data[0], size[0], freq[0]);
        ALut.alutUnloadWAV(format[0], data[0], size[0], freq[0]);

        ALut.alutLoadWAVFile("wavdata/rain.wav", format, data, size, freq, loop);
        al.alBufferData(buffers[RAIN], format[0], data[0], size[0], freq[0]);
        ALut.alutUnloadWAV(format[0], data[0], size[0], freq[0]);

        ALut.alutLoadWAVFile("wavdata/ocean.wav", format, data, size, freq, loop);
        al.alBufferData(buffers[OCEAN], format[0], data[0], size[0], freq[0]);
        ALut.alutUnloadWAV(format[0], data[0], size[0], freq[0]);

        ALut.alutLoadWAVFile("wavdata/chimes.wav", format, data, size, freq, loop);
        al.alBufferData(buffers[CHIMES], format[0], data[0], size[0], freq[0]);
        ALut.alutUnloadWAV(format[0], data[0], size[0], freq[0]);

        // Do another error check and return.
        if (al.alGetError() != AL.AL_NO_ERROR)
            return AL.AL_FALSE;

        return AL.AL_TRUE;
    }

    static void addSource(int type) {
        int[] source = new int[1];

        al.alGenSources(1, source);

        if (al.alGetError() != AL.AL_NO_ERROR) {
            System.err.println("Error generating audio source.");
            System.exit(1);
        }

        al.alSourcei (source[0], AL.AL_BUFFER,   buffers[type]);
        al.alSourcef (source[0], AL.AL_PITCH,    1.0f          );
        al.alSourcef (source[0], AL.AL_GAIN,     1.0f          );
        al.alSourcefv(source[0], AL.AL_POSITION, sourcePos    );
        al.alSourcefv(source[0], AL.AL_VELOCITY, sourceVel    );
        al.alSourcei (source[0], AL.AL_LOOPING,  AL.AL_TRUE      );

        al.alSourcePlay(source[0]);

        sources.add(new Integer(source[0]));
    }

    static void setListenerValues() {
        al.alListenerfv(AL.AL_POSITION,    listenerPos);
        al.alListenerfv(AL.AL_VELOCITY,    listenerVel);
        al.alListenerfv(AL.AL_ORIENTATION, listenerOri);
    }

    static void killALData() {

        Iterator iter = sources.iterator();
        while(iter.hasNext()) {
            al.alDeleteSources(1, new int[] { ((Integer)iter.next()).intValue() });
        }
        sources.clear();
        al.alDeleteBuffers(NUM_BUFFERS, buffers);
        exitOpenAL();
    }


    public static void main(String[] args) {
        if(initOpenAL() == AL.AL_FALSE) {
            System.err.println("Could not initialize");
            System.exit(1);
        }
        if(loadALData() == AL.AL_FALSE) {
            System.exit(1);
        }
        setListenerValues();
        char[] c = new char[1];
        while(c[0] != 'q') {    
            try {
                BufferedReader buf =
                    new BufferedReader(new InputStreamReader(System.in));
                System.out.println("Press a key and hit ENTER: \n" +
                                   "\t'w' for Water Drop\n" +
                                   "\t't' for Thunder\n" +
                                   "\t's' for Stream\n" +
                                   "\t'r' for Rain\n" +
                                   "\t'o' for Ocean\n" +
                                   "\t'c' for Chimes\n" +
                                   "\n'q' to Quit\n");

                buf.read(c);
                switch(c[0]) {
                    case 'w': addSource(WATERDROP); break;
                    case 't': addSource(THUNDER); break;
                    case 's': addSource(STREAM); break;
                    case 'r': addSource(RAIN); break;
                    case 'o': addSource(OCEAN); break;
                    case 'c': addSource(CHIMES); break;
                }
            } catch (IOException e) {
                killALData();
                System.exit(1);
            }
        }
        killALData();
    }
}
